export class Car {
  id:number = 0;
  make:string = "";
  checked:boolean = false;

  constructor(id:number, make:string){
    this.id = id;
    this.make = make;
  }

}
