import { Component } from '@angular/core';

@Component({
  selector: 'app-d',
  standalone: true,
  imports: [],
  templateUrl: './d.component.html',
  styleUrl: './d.component.css'
})
export class DComponent {

}
