import { Component } from '@angular/core';

@Component({
  selector: 'app-e',
  standalone: true,
  imports: [],
  templateUrl: './e.component.html',
  styleUrl: './e.component.css'
})
export class EComponent {

}
