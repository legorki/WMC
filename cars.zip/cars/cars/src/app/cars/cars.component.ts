import { Component } from '@angular/core';
import {CarsService} from "./cars.service";
import {NgForOf} from "@angular/common";
import {HttpClientModule} from "@angular/common/http";
@Component({
  selector: 'app-cars',
  standalone: true,
  imports: [
    NgForOf
  ],
  templateUrl: './cars.component.html',
  styleUrl: './cars.component.css'
})
export class CarsComponent {
constructor(private carsService: CarsService){

}
cars:string[] = [];
getCars(): void{
  this.carsService.getCars().subscribe(cars => this.cars = cars);
}
ngOnInit(){
  this.getCars();

}
}
